# 在 Android Studio 中构建 APK

当前交付为 Android 源码工程，不是 APK。请在安装了 Android SDK 的电脑上构建：

1. 安装 Android Studio（建议稳定版）和 JDK 17。
2. 打开本目录 `ClassFlow`，等待 Gradle Sync 完成。
3. 在 SDK Manager 中安装 Android SDK Platform 35 和 Android SDK Build-Tools。
4. 连接 Android 手机并允许 USB 调试，点击 Run 安装测试。
5. 生成可分享的调试 APK：菜单 `Build > Build Bundle(s) / APK(s) > Build APK(s)`。
6. 构建成功后，APK 通常位于 `app/build/outputs/apk/debug/app-debug.apk`。

发布给他人安装时，请使用 `Build > Generate Signed Bundle / APK` 创建签名 APK，并妥善保存签名密钥。

## 本版本限制
- 图片识别目前输出 OCR 文字供核对，尚未针对各高校课表模板实现可靠的自动表格解析。
- 课程提醒与桌面组件是第一版基础实现，必须在目标手机上验证通知权限、精确闹钟权限、后台限制和小组件刷新。
- 不同 MIUI/HyperOS 版本及桌面启动器对小组件尺寸的呈现可能不同。
