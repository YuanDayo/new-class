package com.classflow.app.widget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.widget.RemoteViews
import com.classflow.app.R
import com.classflow.app.data.ClassFlowDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.DayOfWeek
import java.time.LocalDateTime

class NextClassWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        CoroutineScope(Dispatchers.IO).launch {
            val courses = ClassFlowDatabase.get(context).courseDao().getAll()
            val now = LocalDateTime.now()
            val today = now.dayOfWeek.value
            val next = courses.filter { it.dayOfWeek >= today }
                .sortedWith(compareBy({ if (it.dayOfWeek == today && it.startMinute < now.hour * 60 + now.minute) 99 else it.dayOfWeek }, { it.startMinute }))
                .firstOrNull()
            ids.forEach { id ->
                val views = RemoteViews(context.packageName, R.layout.widget_next_class)
                if (next == null) {
                    views.setTextViewText(R.id.widget_course, "暂时没有课程")
                    views.setTextViewText(R.id.widget_detail, "添加课程后将在这里显示")
                } else {
                    val time = "%02d:%02d".format(next.startMinute / 60, next.startMinute % 60)
                    views.setTextViewText(R.id.widget_course, next.name)
                    views.setTextViewText(R.id.widget_detail, "${next.location.ifBlank { "地点待定" }} · $time")
                }
                manager.updateAppWidget(id, views)
            }
        }
    }
}
