package com.classflow.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [Course::class], version = 1, exportSchema = false)
abstract class ClassFlowDatabase : RoomDatabase() {
    abstract fun courseDao(): CourseDao
    companion object {
        @Volatile private var INSTANCE: ClassFlowDatabase? = null
        fun get(context: Context): ClassFlowDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext, ClassFlowDatabase::class.java, "classflow.db"
                ).build().also { INSTANCE = it }
            }
    }
}
