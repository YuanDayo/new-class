package com.classflow.app

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.classflow.app.data.ClassFlowDatabase
import com.classflow.app.data.Course
import com.classflow.app.reminder.ReminderScheduler
import com.classflow.app.widget.NextClassWidget
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import kotlinx.coroutines.launch

private val Ink = Color(0xFF1D3E70)
private val Blue = Color(0xFF3978D5)
private val Pale = Color(0xFFEAF2FF)
private val Muted = Color(0xFF718096)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
        setContent { MaterialTheme(colorScheme = lightColorScheme(primary = Blue, background = Color(0xFFF7F9FC))) { ClassFlowApp() } }
    }
}

@Composable
private fun ClassFlowApp() {
    val context = LocalContext.current
    val dao = remember { ClassFlowDatabase.get(context).courseDao() }
    val courses by dao.observeAll().collectAsStateWithLifecycle(initialValue = emptyList())
    var showEditor by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Course?>(null) }
    var ocrText by remember { mutableStateOf("") }
    var showOcr by remember { mutableStateOf(false) }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            try {
                val image = InputImage.fromFilePath(context, uri)
                TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
                    .process(image)
                    .addOnSuccessListener { result -> ocrText = result.text; showOcr = true }
                    .addOnFailureListener { ocrText = "识别失败：${it.localizedMessage}"; showOcr = true }
            } catch (e: Exception) { ocrText = "无法读取图片：${e.localizedMessage}"; showOcr = true }
        }
    }

    Scaffold(
        containerColor = Color(0xFFF7F9FC),
        floatingActionButton = {
            FloatingActionButton(onClick = { editing = null; showEditor = true }, containerColor = Blue, contentColor = Color.White) {
                Icon(Icons.Default.Add, contentDescription = "添加课程")
            }
        }
    ) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("ClassFlow", color = Ink, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                        Text("SMART UNIVERSITY TIMETABLE", color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
                    }
                    Text("2026 · 秋季学期", color = Muted, fontSize = 12.sp)
                }
            }
            item {
                val nowDay = java.time.LocalDate.now().dayOfWeek.value
                val nowMinute = java.time.LocalTime.now().hour * 60 + java.time.LocalTime.now().minute
                val next = courses.firstOrNull { it.dayOfWeek == nowDay && it.startMinute >= nowMinute }
                    ?: courses.firstOrNull()
                Column(Modifier.fillMaxWidth().background(Pale, RoundedCornerShape(22.dp)).padding(18.dp)) {
                    Text("NEXT CLASS · 下一节课程", color = Color(0xFF5275A8), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp))
                    Text(next?.name ?: "今天暂时没有课程", color = Ink, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Text(if (next == null) "添加课程，开始使用 ClassFlow" else "${dayLabel(next.dayOfWeek)} · ${clock(next.startMinute)} - ${clock(next.endMinute)} · ${next.location.ifBlank { "地点待定" }}", color = Color(0xFF496B99), fontSize = 12.sp)
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("我的课程", color = Ink, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    TextButton(onClick = { imagePicker.launch("image/*") }) {
                        Icon(Icons.Default.CameraAlt, null, modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(5.dp)); Text("照片导入")
                    }
                }
            }
            if (courses.isEmpty()) {
                item {
                    Column(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(18.dp)).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("还没有课程", color = Ink, fontWeight = FontWeight.SemiBold)
                        Text("点击右下角添加，或导入学校课表照片", color = Muted, fontSize = 12.sp)
                    }
                }
            } else {
                items(courses, key = { it.id }) { course ->
                    Row(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(16.dp)).clickable { editing = course; showEditor = true }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.width(74.dp)) {
                            Text(dayLabel(course.dayOfWeek), color = Blue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text(clock(course.startMinute), color = Muted, fontSize = 11.sp)
                        }
                        Column(Modifier.weight(1f)) {
                            Text(course.name, color = Ink, fontWeight = FontWeight.SemiBold)
                            Text("${course.location.ifBlank { "地点待定" }} · ${course.weeks}周", color = Muted, fontSize = 11.sp)
                        }
                        IconButton(onClick = { editing = course; showEditor = true }) { Icon(Icons.Default.Edit, null, tint = Muted) }
                        IconButton(onClick = { ReminderScheduler.cancel(context, course.id); kotlinx.coroutines.MainScope().launch { dao.delete(course); refreshWidget(context) } }) {
                            Icon(Icons.Default.Delete, null, tint = Color(0xFFB45B64))
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(70.dp)) }
        }
    }

    if (showEditor) {
        CourseEditor(initial = editing, onDismiss = { showEditor = false }) { course ->
            kotlinx.coroutines.MainScope().launch {
                val id = dao.upsert(course)
                val saved = course.copy(id = if (course.id == 0L) id else course.id)
                ReminderScheduler.schedule(context, saved)
                refreshWidget(context)
            }
            showEditor = false
        }
    }
    if (showOcr) {
        AlertDialog(onDismissRequest = { showOcr = false }, title = { Text("照片识别结果") },
            text = { Column {
                Text("已提取图片文字。请核对后手动添加课程；不同学校课表格式需要进一步配置解析规则。", fontSize = 12.sp, color = Muted)
                Spacer(Modifier.height(8.dp))
                Text(ocrText, fontSize = 13.sp, color = Ink)
            } },
            confirmButton = { TextButton(onClick = { showOcr = false }) { Text("知道了") } })
    }
}

@Composable
private fun CourseEditor(initial: Course?, onDismiss: () -> Unit, onSave: (Course) -> Unit) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var teacher by remember { mutableStateOf(initial?.teacher ?: "") }
    var location by remember { mutableStateOf(initial?.location ?: "") }
    var day by remember { mutableStateOf((initial?.dayOfWeek ?: 1).toString()) }
    var start by remember { mutableStateOf(initial?.startMinute?.let(::clock) ?: "08:00") }
    var end by remember { mutableStateOf(initial?.endMinute?.let(::clock) ?: "09:40") }
    var weeks by remember { mutableStateOf(initial?.weeks ?: "1-16") }
    var reminder by remember { mutableStateOf((initial?.reminderMinutes ?: 10).toString()) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (initial == null) "添加课程" else "编辑课程") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("课程名称") }, singleLine = true)
            OutlinedTextField(location, { location = it }, label = { Text("上课地点") }, singleLine = true)
            OutlinedTextField(teacher, { teacher = it }, label = { Text("教师（选填）") }, singleLine = true)
            OutlinedTextField(day, { day = it }, label = { Text("星期（1=周一，7=周日）") }, singleLine = true)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(start, { start = it }, label = { Text("开始 HH:mm") }, modifier = Modifier.weight(1f), singleLine = true)
                OutlinedTextField(end, { end = it }, label = { Text("结束 HH:mm") }, modifier = Modifier.weight(1f), singleLine = true)
            }
            OutlinedTextField(weeks, { weeks = it }, label = { Text("周数，例如 1-16") }, singleLine = true)
            OutlinedTextField(reminder, { reminder = it }, label = { Text("提前提醒分钟数") }, singleLine = true)
        } },
        confirmButton = { TextButton(onClick = {
            val d = day.toIntOrNull()?.coerceIn(1,7) ?: 1
            val s = parseClock(start); val e = parseClock(end)
            if (name.isNotBlank() && s != null && e != null && e > s) {
                onSave(Course(id = initial?.id ?: 0, name = name.trim(), teacher = teacher, location = location,
                    dayOfWeek = d, startMinute = s, endMinute = e, weeks = weeks,
                    reminderMinutes = reminder.toIntOrNull()?.coerceIn(0,180) ?: 10))
            }
        }) { Text("保存") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("取消") } })
}

private fun parseClock(value: String): Int? = try {
    val parts = value.trim().split(":"); parts[0].toInt() * 60 + parts[1].toInt()
} catch (_: Exception) { null }
private fun clock(minutes: Int) = "%02d:%02d".format(minutes / 60, minutes % 60)
private fun dayLabel(day: Int) = listOf("周一","周二","周三","周四","周五","周六","周日").getOrElse(day-1) { "周一" }
private fun refreshWidget(context: android.content.Context) {
    val manager = AppWidgetManager.getInstance(context)
    val ids = manager.getAppWidgetIds(ComponentName(context, NextClassWidget::class.java))
    NextClassWidget().onUpdate(context, manager, ids)
}
