package com.classflow.app.reminder

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.classflow.app.MainActivity
import com.classflow.app.data.ClassFlowDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra("course_id", -1L)
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val dao = ClassFlowDatabase.get(context).courseDao()
                val course = dao.getById(id) ?: return@launch
                val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                if (Build.VERSION.SDK_INT >= 26) {
                    manager.createNotificationChannel(
                        NotificationChannel("classflow_reminders", "课程提醒", NotificationManager.IMPORTANCE_HIGH)
                    )
                }
                val openApp = PendingIntent.getActivity(
                    context, 0, Intent(context, MainActivity::class.java),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                val time = "%02d:%02d".format(course.startMinute / 60, course.startMinute % 60)
                val notification = NotificationCompat.Builder(context, "classflow_reminders")
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle("即将上课：${course.name}")
                    .setContentText("$time · ${course.location.ifBlank { "地点待定" }}")
                    .setContentIntent(openApp).setAutoCancel(true).build()
                manager.notify(id.toInt(), notification)
                ReminderScheduler.schedule(context, course)
            } finally { pendingResult.finish() }
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                ClassFlowDatabase.get(context).courseDao().getAll().forEach {
                    ReminderScheduler.schedule(context, it)
                }
            } finally { pendingResult.finish() }
        }
    }
}
