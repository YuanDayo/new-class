package com.classflow.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "courses")
data class Course(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val teacher: String = "",
    val location: String = "",
    val dayOfWeek: Int, // 1=Monday ... 7=Sunday
    val startMinute: Int,
    val endMinute: Int,
    val weeks: String = "1-16",
    val color: Long = 0xFFEAF2FF,
    val reminderMinutes: Int = 10
)
