package com.classflow.app.reminder

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.classflow.app.data.Course
import java.time.DayOfWeek
import java.time.LocalDateTime
import java.time.temporal.TemporalAdjusters

object ReminderScheduler {
    fun schedule(context: Context, course: Course) {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra("course_id", course.id)
        }
        val pending = PendingIntent.getBroadcast(
            context, course.id.toInt(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val now = LocalDateTime.now()
        val targetDay = DayOfWeek.of(course.dayOfWeek)
        var next = now.with(TemporalAdjusters.nextOrSame(targetDay))
            .withHour(course.startMinute / 60).withMinute(course.startMinute % 60)
            .withSecond(0).withNano(0)
            .minusMinutes(course.reminderMinutes.toLong())
        if (!next.isAfter(now)) next = next.plusWeeks(1)
        val trigger = next.atZone(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
        alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pending)
    }

    fun cancel(context: Context, courseId: Long) {
        val intent = Intent(context, ReminderReceiver::class.java)
        val pending = PendingIntent.getBroadcast(
            context, courseId.toInt(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending)
    }
}
