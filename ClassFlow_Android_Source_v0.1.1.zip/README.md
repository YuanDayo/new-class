# ClassFlow — 大学智能课程表

Android 原生项目起始版本，采用 Kotlin、Jetpack Compose、Room、ML Kit 中文 OCR 和 Android AppWidget。

## 当前工程包含
- 蓝白扁平化 Compose 首页、周课表和课程编辑/删除
- 本地 Room 持久化
- 从图片选择器导入课表图片，调用 ML Kit 中文文字识别
- OCR 结果预览；识别结果可复制/参考后手动录入（不同学校版式差异较大，尚未自动可靠地解析为完整课程）
- 课前提醒：按课程星期和时间设置提醒，使用 Android AlarmManager
- Android 桌面 AppWidget：显示下一节课程
- 开机广播接收器：重新安排提醒

## 环境
- Android Studio Ladybug 或更新版本
- JDK 17
- Android SDK 35
- Gradle 8.9（Android Studio 可自动下载）

打开项目根目录即可同步 Gradle。

## 重要说明
这是可继续开发的源码工程，不是已经签名的 APK。需要在 Android Studio 中构建、安装并在真机上验证。
MIUI/HyperOS 对后台启动、通知和桌面组件有额外限制。首次运行需授予通知权限；若系统限制后台提醒，请在系统设置中允许自启动/后台运行，并按需允许精确闹钟。
Android 版本、MIUI/HyperOS 版本及桌面启动器会影响小组件的尺寸和刷新表现。

## 下一步建议
1. 根据学校真实课表样本完善 OCR 表格结构解析与冲突检测。
2. 增加学期周数、单双周、节假日/调课管理。
3. 增加 2x2、4x2、4x4 等多尺寸桌面组件布局。
4. 在目标小米手机上验证锁屏通知、后台提醒和组件刷新。


## APK 构建
详细步骤见 [BUILD_APK.md](BUILD_APK.md)。本交付不包含已编译 APK。
