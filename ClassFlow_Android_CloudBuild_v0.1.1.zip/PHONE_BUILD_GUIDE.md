# ClassFlow 手机云端打包指南（GitHub Actions）

本工程已附带 `.github/workflows/build-apk.yml`，可由 GitHub 云端使用 JDK 17、Gradle 8.9 和 Android SDK 35 构建 debug APK。

## 只用手机操作
1. 在手机浏览器打开 https://github.com/ 并登录/注册账号。
2. 点击右上角 `+` → `New repository`，仓库名可填 `ClassFlow`，选择 `Private`，创建仓库。
3. 在仓库页面选择 `Add file` → `Upload files`，上传本 ZIP 解压后的**全部文件和文件夹**。注意 `.github` 是隐藏目录；如果手机文件管理器看不到隐藏目录，请先在 GitHub 网页端创建 `.github/workflows/build-apk.yml`，再粘贴本项目同名文件的内容。
4. 点击 `Commit changes`。
5. 打开仓库顶部 `Actions`，选择 `Build ClassFlow APK` → `Run workflow` → `Run workflow`。
6. 等待任务完成（绿色勾号），进入本次运行页面底部的 `Artifacts`，下载 `ClassFlow-debug-apk`。
7. 下载得到 ZIP，解压后安装 `app-debug.apk`。首次安装可能需要允许浏览器/文件管理器“安装未知应用”。

## 注意
- 这是 debug APK，适合自己测试和安装；不是面向商店发布的正式签名包。
- 仓库建议设为 Private。不要把签名密钥、密码或 API 密钥上传到仓库。
- 首次构建需要下载 Android/Gradle 依赖，耗时取决于网络和 GitHub runner。
- 该工作流只负责编译；仍需在手机上验证课程提醒、通知权限和 MIUI/HyperOS 桌面小组件行为。
